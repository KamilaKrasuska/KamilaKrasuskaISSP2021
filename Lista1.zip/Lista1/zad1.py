a=input()
b=input()
suma=a+b #liczby wpisywane program interpretuje jako stringi
print(suma) #dlatego program interpretuje sume jako dodawanie stringow
a=int(a)
b=int(b)
suma=a+b
print(suma) #po rzutowaniu zmiennych suma jest dodawaniem dwoch intow