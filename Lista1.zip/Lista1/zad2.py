import math
a=3
b=4
kat=47
kat=math.radians(kat)
skat=math.sin(kat)
p=(1/2)*a*b*skat
print(p)