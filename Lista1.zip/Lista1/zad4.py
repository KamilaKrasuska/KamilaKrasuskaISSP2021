import builtins
print(dir(builtins))
#help(print)
print("Ala ma kota")
print(2+2)
print(2**5,35//2,35/2,35%2, sep='\t')
print(2**5,35//2,35/2,35%2, sep='\n')