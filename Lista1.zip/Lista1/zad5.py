import math
print(5//3) #dzielenie z czescia calkowita
a=5/3 #liczba zmiennoprzecinkowa
#help(math.floor)
#help(round)
print(round(a)) #zaokrągla odnosząc się do liczb po przecinku
#tj liczbe 1-4 po przecinku zaokragla w dół a liczbe 5-9 w góre
print(math.floor(a)) #zaokrągla w dół
