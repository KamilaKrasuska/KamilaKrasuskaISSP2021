import math
print(complex(-17.0,0)**(1/2))
print((-17)**(1/2))