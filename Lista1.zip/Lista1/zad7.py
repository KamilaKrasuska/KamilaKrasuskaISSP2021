import math
2+2
print(_)
#zmienna _ działa jedynie w trybie interakywnym
#do zmienna=ej _ w trybie interaktywnym jest przypisywana wynik ostatniego działania